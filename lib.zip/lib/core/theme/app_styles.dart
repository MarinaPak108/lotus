import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppStyles {
  static final title = GoogleFonts.lato(
    fontSize: 28,
    fontWeight: FontWeight.w600,
    color: Colors.green,
  );

  static final body = GoogleFonts.lato(
    fontSize: 18,
    fontWeight: FontWeight.w500,
    color: Color.fromARGB(255, 122, 188, 125),
  );

  static final date = GoogleFonts.lato(
    fontSize: 20,
    fontWeight: FontWeight.w400,
    color: Color.fromARGB(255, 105, 105, 105),
  );

  static final noteTitle = GoogleFonts.lato(
    fontSize: 22,
    fontWeight: FontWeight.w500,
    color: Color.fromARGB(255, 178, 184, 178),
  );
}
