import 'package:flutter/material.dart';
import 'package:sm_project/presentation/pages/login_page.dart';

class SplashPage extends StatelessWidget {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const _Splash();
  }
}

class _Splash extends StatefulWidget {
  const _Splash({super.key});

  @override
  State<_Splash> createState() => _SplashState();
}

class _SplashState extends State<_Splash> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 5), _routeUser);
  }

  void _routeUser() {
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (cxt) => LoginPage()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SizedBox(
            width: MediaQuery.sizeOf(context).width,
            height: MediaQuery.sizeOf(context).height,
            child: Image.asset(
              'assets/img/splash.jpg',
              fit: BoxFit.fitHeight,
            )));
  }
}
