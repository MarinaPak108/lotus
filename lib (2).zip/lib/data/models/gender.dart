class Gender {
  final String name;

  Gender({required this.name});
}
