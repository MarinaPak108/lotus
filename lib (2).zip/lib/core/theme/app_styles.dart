import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppStyles {
  static const activeMainC = Color.fromARGB(255, 44, 179, 48);
  static const activeLightC = Colors.green;
  static const notActiveC = Color.fromARGB(255, 105, 105, 105);
  static const notActiveDarkC = Color.fromARGB(255, 47, 47, 47);

  static const labelFontSize = 25;
  static const inputInfoFontSize = 28;

  static const borderActive =
      OutlineInputBorder(borderSide: BorderSide(color: activeMainC, width: 3));
  static const borderNonActive =
      OutlineInputBorder(borderSide: BorderSide(color: notActiveC, width: 3));
  static final title = GoogleFonts.lato(
    fontSize: 28,
    fontWeight: FontWeight.w600,
    color: Colors.green,
  );

  static final body = GoogleFonts.lato(
    fontSize: 18,
    fontWeight: FontWeight.w500,
    color: Color.fromARGB(255, 122, 188, 125),
  );

  static final date = GoogleFonts.lato(
    fontSize: 20,
    fontWeight: FontWeight.w400,
    color: Color.fromARGB(255, 105, 105, 105),
  );

  static final noteTitle = GoogleFonts.lato(
    fontSize: 22,
    fontWeight: FontWeight.w500,
    color: Color.fromARGB(255, 178, 184, 178),
  );
}
