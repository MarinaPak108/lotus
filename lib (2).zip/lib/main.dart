import 'package:flutter/material.dart';
import 'package:sm_project/data/datasource/local_data/database_helper.dart';
import 'package:sm_project/presentation/pages/splash_page.dart';

import 'injection.dart' as di;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final db = DatabaseHelper();
  await db.initDB();
  await di.init();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
        debugShowCheckedModeBanner: false, title: 'SM App', home: SplashPage());
    // SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

    // return MultiProvider(
    //   providers: [BlocProvider(create: (_) => di.locator<NoteBloc>())],
    //   child: const MaterialApp(
    //     title: 'Flutter Note App',
    //     debugShowCheckedModeBanner: false,
    //     home: HomePage(),
    //   ),
    // );
  }
}
